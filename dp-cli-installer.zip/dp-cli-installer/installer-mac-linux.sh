#!/bin/bash

DDT_PATH=~/.ddt/dp
INSTALLATION_PATH=/usr/local/bin
SCRIPT_PATH=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

echo "Installing CLI, you will be prompted for your password."

# Remove old installation
if [ -e "$INSTALLATION_PATH/dp.jar" ]; then
    echo "Found an old installation, removing '$INSTALLATION_PATH/dp.jar'"
    sudo rm "$INSTALLATION_PATH/dp.jar"
fi

# New installation
mkdir -p "$DDT_PATH"
mv "$SCRIPT_PATH/data-product-cli.jar" $DDT_PATH/dp.jar
tee  $DDT_PATH/dp-cli > /dev/null <<EOT
#!/bin/bash
java -jar $DDT_PATH/dp.jar "\$@"
EOT
chmod +x "$DDT_PATH/dp-cli"

sudo ln -sf "$DDT_PATH/dp-cli" "$INSTALLATION_PATH/dp"

echo ""
echo "Installation finished. You can remove this file. You can run the CLI with 'dp'"
